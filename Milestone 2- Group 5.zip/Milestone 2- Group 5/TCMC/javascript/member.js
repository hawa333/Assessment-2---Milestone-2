// JavaScript Document

function formValidation()
{
var uname = document.membership.uname;
var lname = document.membership.lname;
var uadd = document.membership.address;
var ucountry = document.membership.country;
var uzip = document.membership.zip;
var uemail = document.membership.email;
var umsex = document.membership.msex;
var ufsex = document.membership.fsex;

if(allLetter(uname))
{
if(allLetter(lname))
{
if(alphanumeric(uadd))
{ 
if(countryselect(ucountry))
{
if(allnumeric(uzip))
{
if(ValidateEmail(uemail))
{
if(validsex(umsex,ufsex))
{
}
}
}
} 
}
}
}

return false;
}

//username
function allLetter(lname)
{ 
var letters = /^[A-Za-z]+$/;
if(lname.value.match(letters))
{
return true;
}
else
{
alert("First Name & last Name must have alphabet characters only");
lname.focus();
return false;
}
}


//address
function alphanumeric(uadd)
{ 
var letters = /^[0-9a-zA-Z]+$/;
if(uadd.value.match(letters))
{
return true;
}
else
{
alert("User address must have alphanumeric characters only");
uadd.focus();
return false;
}
}


//country
function countryselect(ucountry)
{
if(ucountry.value == "Default")
{
alert("Select your country from the list");
ucountry.focus();
return false;
}
else
{
return true;
}
}


// zip
function allnumeric(uzip)
{ 
var numbers = /^[0-9]+$/;
if(uzip.value.match(numbers))
{
return true;
}
else
{
alert("ZIP code must have numeric characters only");
uzip.focus();
return false;
}
}


//email
function ValidateEmail(uemail)
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(uemail.value.match(mailformat))
{
return true;
}
else
{
alert("You have entered an invalid email address!");
uemail.focus();
return false;
}
}

//

function validsex(umsex,ufsex)
{
x=0;

if(umsex.checked) 
{
x++;
} if(ufsex.checked)
{
x++; 
}
if(x==0)
{
alert("Select Male/Female");
umsex.focus();
return false;
}
else
{
alert("Form Successfully Submitted");
window.location.reload();
return true;}
}