// JavaScript Document

function formValidation()
{
var uadd = document.payment.address;
var uemail = document.payment.email;
var ucountry = document.payment.card;
var uname = document.payment.uname;
var unum = document.payment.unum;
var ucc = document.payment.cc;
var udc = document.payment.dc;
var ucvv = document.payment.cvv;
if(alphanumeric(uadd))
{ 
if(ValidateEmail(uemail))
{
if(countryselect(ucountry))
{		
if(allLetter(uname))
{
if(allnumeric(unum))
{

if(allnumeric(ucvv))
{
	if(validsex(ucc,udc))
{
}
}
}
}
}
}
}
return false;
}


//address
function alphanumeric(uadd)
{ 
var letters = /^[0-9a-zA-Z]+$/;
if(uadd.value.match(letters))
{
return true;
}
else
{
alert("Billing address must have alphanumeric characters only");
uadd.focus();
return false;
}
}


//email
function ValidateEmail(uemail)
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(uemail.value.match(mailformat))
{
return true;
}
else
{
alert("You have entered an invalid email address!");
uemail.focus();
return false;
}
}

//username
function allLetter(lname)
{ 
var letters = /^[A-Za-z]+$/;
if(lname.value.match(letters))
{
return true;
}
else
{
alert("Name must have alphabets only");
lname.focus();
return false;
}
}


//selesct card
function countryselect(ucountry)
{
if(ucountry.value == "Default")
{
alert("Select card type from the list");
ucountry.focus();
return false;
}
else
{
return true;
}
}


// Card number & CVV
function allnumeric(ucvv)
{ 
var numbers = /^[0-9]+$/;
if(ucvv.value.match(numbers))
{
return true;
}
else
{
alert("Card number & CVV must have numeric characters only");
ucvv.focus();
return false;
}
}


//card type
function validsex(ucc,udc)
{
x=0;

if(ucc.checked) 
{
x++;
} if(udc.checked)
{
x++; 
}
if(x==0)
{
alert("Select Credit Card/Debit Card");
ucc.focus();
return false;
}
else
{
alert(" Payment was Successful");
window.location.reload();
}
}